/**
 * 
 */
package tarea5_1;

/**
 * 
 */
public class SubClase extends ClaseAbstracta {

	@Override
	public void abstract_method() {
		System.out.println("Este es un método abstracto implementado en una clase no abstracta");
	}

}
