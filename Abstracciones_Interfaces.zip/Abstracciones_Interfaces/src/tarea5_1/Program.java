/**
 * 
 */
package tarea5_1;

/**
 * 
 */
public class Program {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SubClase sb = new SubClase();
		
		sb.abstract_method();
		sb.no_abstract_method();

	}

}
